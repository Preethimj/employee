package com.cg.mob.dao;


import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public interface MobileDAO {
public double purchaseMobile(Customer c,Mobile m);
public Mobile getPurchaseDetails(long orderId);
public void  addcustomerdetails(long custid,Customer c ) ;
public void addMobiledetails(long orderid, Mobile m);
}
