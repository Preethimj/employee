package com.cg.mob.dao;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.util.Util;


public class MobileDAOImp implements MobileDAO {

	@Override
	public double purchaseMobile(Customer c, Mobile m) {
		
		return Util.purchaseMobile(c, m);
	}

	@Override
	public Mobile getPurchaseDetails(long orderId) {
		
		return Util.getPurchaseDetails(orderId);
	}

	@Override
	public void addcustomerdetails(long custid, Customer c) {
		
		Util.addcustomerdetails(custid, c);
	}

	@Override
	public void addMobiledetails(long orderid, Mobile m) {
		
		Util.addMobiledetails(orderid, m);
	}

}
