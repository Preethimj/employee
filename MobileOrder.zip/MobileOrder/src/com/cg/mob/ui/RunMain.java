package com.cg.mob.ui;

import java.util.Scanner;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.exception.MobileException;
import com.cg.mob.service.MobileService;
import com.cg.mob.service.MobileserviceImp;
public class RunMain 
{
	static Scanner sc=null;
	static MobileService mobileservice=null;
	public static void main(String[] args) throws MobileException
	{
		sc=new Scanner(System.in);
		mobileservice=new MobileserviceImp();
		while(true) {
		System.out.println("**************");
		System.out.println("1.Place Mobile order");
		System.out.println("2.get order details");
		int choice=sc.nextInt();
		
		switch(choice) {
		case 1:
			purchaseMobile();
			break;
		case 2:
			getPurchaseDetails();
			break;
			
		}
	}
	}
	private static void getPurchaseDetails() {
		System.out.println("Enter the orderid");
		long orderid=sc.nextInt();
		Mobile m=mobileservice.getPurchaseDetails(orderid);
		System.out.println(m);
		
		
	}
	private static void purchaseMobile() {
	System.out.println("Enter customer's name");
	String name=sc.next();
	try {
		if(mobileservice.ValidateName(name)) {
			System.out.println("Enter customer's number");
			String num=sc.next();
			if(mobileservice.ValidateNumber(num)) {
				System.out.println("Enter customer's address");
				String address=sc.next();
				System.out.println("Enter the customer id");
				long custid=sc.nextLong();
				System.out.println("Enter Mobile Model");
				System.out.println("1.Asus");
				System.out.println("2.moto");
				System.out.println("3.gionee");
				int ch=sc.nextInt();
				int price=0;
				switch(ch) {
				case 1:
					price=12000;
					break;
				case 2:
					price=16000;
					break;
				case 3:
					price=13000;
					break;
				case 4:
					System.exit(0);
					}
				System.out.println("Price of the mobile is "+price);
				long orderid=(int)Math.round(Math.random()*999999999);
				Mobile m=new Mobile(orderid,custid,price);
				Customer c=new Customer(name,num,address);
				mobileservice.addcustomerdetails(custid, c);
				mobileservice.addMobiledetails(orderid, m);
				long orderid1=(long) mobileservice.purchaseMobile(c, m);
				System.out.println("you have successfully purchased the mobile and your orderid is..."+orderid);
			
			}
			}
	}catch(Exception e) {
		System.out.println("Exception occured");
	}
	}
		
	}
	

