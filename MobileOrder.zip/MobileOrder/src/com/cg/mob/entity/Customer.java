package com.cg.mob.entity;

public class Customer {
private String Customername;
private String address;
private String mobileno;
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String customername, String address, String mobileno) {
	super();
	Customername = customername;
	this.address = address;
	this.mobileno = mobileno;
}
public String getCustomername() {
	return Customername;
}
public void setCustomername(String customername) {
	Customername = customername;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
@Override
public String toString() {
	return "Customer [Customername=" + Customername + ", address=" + address + ", mobileno=" + mobileno + "]";
}

}
