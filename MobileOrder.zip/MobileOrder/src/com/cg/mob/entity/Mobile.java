package com.cg.mob.entity;

public class Mobile {
private long orderid;
private double customerid;
private float totalprice;
public Mobile() {
	super();
	// TODO Auto-generated constructor stub
}
public Mobile(long orderid, double customerid, float totalprice) {
	super();
	this.orderid = orderid;
	this.customerid = customerid;
	this.totalprice = totalprice;
}
public long getOrderid() {
	return orderid;
}
public void setOrderid(long orderid) {
	this.orderid = orderid;
}
public double getCustomerid() {
	return customerid;
}
public void setCustomerid(double customerid) {
	this.customerid = customerid;
}
public float getTotalprice() {
	return totalprice;
}
public void setTotalprice(float totalprice) {
	this.totalprice = totalprice;
}
@Override
public String toString() {
	return "Mobile [orderid=" + orderid + ", customerid=" + customerid + ", totalprice=" + totalprice + "]";
}

}
