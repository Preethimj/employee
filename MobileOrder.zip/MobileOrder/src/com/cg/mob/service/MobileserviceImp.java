package com.cg.mob.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mob.dao.MobileDAO;
import com.cg.mob.dao.MobileDAOImp;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public class MobileserviceImp implements MobileService {
MobileDAO mb=new MobileDAOImp();
	@Override
	public double purchaseMobile(Customer c, Mobile m) {
		
		return mb.purchaseMobile(c, m);
	}

	@Override
	public Mobile getPurchaseDetails(long orderId) {
		
	Mobile mc= mb.getPurchaseDetails(orderId);
	return mc;
	}

	@Override
	public boolean ValidateName(String name) {
		Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]{3,10}");
		Matcher m=pattern.matcher(name);
		if(m.matches()) {
			return true;
		}
		else
			System.out.println("enter valid name");
			
		return false;
	}

	@Override
	public boolean ValidateNumber(String num) {
		Pattern pattern=Pattern.compile("[0-9]{10}");
		Matcher m=pattern.matcher(num);
		if(m.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public void addcustomerdetails(long custid, Customer c) {
		mb.addcustomerdetails(custid, c);
	}

	@Override
	public void addMobiledetails(long orderid, Mobile m) {
	mb.addMobiledetails(orderid, m);
	}

}
