package com.cg.mob.service;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public interface MobileService {
	double purchaseMobile(Customer c,Mobile m);
	Mobile getPurchaseDetails(long orderId);
	boolean ValidateName(String name);
	boolean ValidateNumber(String num);
	public void addcustomerdetails(long custid,Customer c ) ;
	public void addMobiledetails(long orderid, Mobile m);
}
