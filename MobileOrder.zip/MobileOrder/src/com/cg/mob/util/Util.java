package com.cg.mob.util;

import java.util.HashMap;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public class Util {
static HashMap<Long,Mobile> hs=new HashMap<Long,Mobile>();
static {
	hs.put((long) 1001,new Mobile(1001,1234,12000.0f));
	hs.put((long) 1004,new Mobile(1004,9878,10000.0f));
	hs.put((long) 1002,new Mobile(1002,8989,23000.0f));
}
static HashMap<Long,Customer> hm=new HashMap<Long,Customer>();
static {
	hm.put((long) 1234,new Customer("Sheela","vizag","8375655579"));
	hm.put((long) 9878,new Customer("Shamlin","tamil nadu","7659077221"));
	hm.put((long) 8989,new Customer("Avinash","kerala","7856431234"));
}
public static double purchaseMobile(Customer c, Mobile m) {
	
	return m.getOrderid();
}

public static Mobile getPurchaseDetails(long orderId) {
	
	return hs.get(orderId);
}
public static void addcustomerdetails(long custid,Customer c ) {
	hm.put(custid, c);

	}
	public static void addMobiledetails(long orderid,Mobile m) {
	hs.put(orderid, m);
	}
}