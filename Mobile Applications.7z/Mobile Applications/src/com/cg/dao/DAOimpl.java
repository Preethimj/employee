package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.exception.CusException;
import com.cg.util.Util;

public class DAOimpl implements DAO {

	@Override
	public HashMap<Integer, Mobile> addmobiledetails(int o, Mobile md) {
		// TODO Auto-generated method stub
		HashMap<Integer, Mobile> hm=Util.addmobiledetails(md);
		return hm;
	}

	@Override
	public HashMap<String, Customer> addcustomerdetails(Customer c) throws CusException {
		// TODO Auto-generated method stub
		HashMap<String, Customer> hm=Util.addcustomerdetails(c);
		return hm;
	}

	@Override
	public HashMap<Integer, Mobile> removemobile(int id) {
		// TODO Auto-generated method stub
		HashMap<Integer, Mobile> m=Util.removemobile(id);
		return m;
	}

	@Override
	public HashMap<String, Customer> removecustomer(int mobileno) {
		// TODO Auto-generated method stub
		HashMap<String, Customer> c=Util.removecustomer(mobileno);
		return c;
	}

	@Override
	public ArrayList<Mobile> sorting() {
		// TODO Auto-generated method stub
		ArrayList<Mobile> s=Util.sorting();
		return s;
	}
	@Override
	public ArrayList<Mobile> sorting1() {
		// TODO Auto-generated method stub
		ArrayList<Mobile> s=Util.sorting1();
		return s;
	}
	@Override
	public ArrayList<Mobile> sorting2() {
		// TODO Auto-generated method stub
		ArrayList<Mobile> s=Util.sorting2();
		return s;
	}public Map<String, Customer>  display() {
		// TODO Auto-generated method stub
		Map<String, Customer> c=Util.display1();
		return c;
	}
}


	@Override
	