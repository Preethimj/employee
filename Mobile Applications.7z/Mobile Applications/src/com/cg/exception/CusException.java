package com.cg.exception;

public class CusException extends Exception{

}
