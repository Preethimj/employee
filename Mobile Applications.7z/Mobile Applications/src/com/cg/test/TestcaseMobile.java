package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.dao.DAO;
import com.cg.dao.DAOimpl;
import com.cg.exception.CusException;
import com.cg.util.Util;

class TestcaseMobile {
	static DAO bdao=new DAOimpl();
	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testaddCustomer() throws CusException {
		assertEquals(bdao.addcustomerdetails(new Customer("Lathisha","Chennai","1234567890")),bdao.addcustomerdetails(new Customer("Lathisha","Chennai","1234567890")));
	}
	@Test
	void testaddMobile() throws CusException {
		assertEquals(bdao.addmobiledetails(108, new Mobile(108,120000,"lenovo")),bdao.addmobiledetails(108, new Mobile(108,120000, "lenovo")));
	}
	@Test
	void testremove() throws CusException {
		assertEquals(bdao.removecustomer(1234567890),bdao.removecustomer(1234567890));
	}
	@Test
	void testremovecmob() throws CusException {
		assertEquals(bdao.removemobile(1),bdao.removemobile(108));
	}
}
