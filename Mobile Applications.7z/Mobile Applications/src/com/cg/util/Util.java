package com.cg.util;

import java.util.ArrayList;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.bean.Sorting;
import com.cg.bean.Sorting1;
import com.cg.bean.Sorting2;



public class Util {
private static HashMap<Integer,Mobile> map=new HashMap<Integer,Mobile>();
private static HashMap<String,Customer> cmap=new HashMap<String,Customer>();
private static ArrayList<Mobile> al = new ArrayList<Mobile>(); 
public static HashMap<String,Customer> display1()
{
	cmap.put("1234567890",new Customer("Lathisha","Chennai","1234567890"));
	cmap.put("1244567890",new Customer("Priya","Mumbai","1244567890"));
	cmap.put("1254567890",new Customer("Hari","Bangalore","1254567890"));
	cmap.put("1264567890",new Customer("karthi","Hydrabad","1264567890"));
	return cmap;
	
}

static 
{

	map.put(101,new Mobile(101,12000,"Asus"));
	map.put(102,new Mobile(102,10000,"Xiaomi"));
	map.put(103,new Mobile(103,50000,"Iphone"));
	map.put(104,new Mobile(104,24000,"Nokia"));
	map.put(105,new Mobile(105,17000,"Sony"));
	cmap.put("1234567890",new Customer("Lathisha","Chennai","1234567890"));
	cmap.put("1244567890",new Customer("Priya","Mumbai","1244567890"));
	cmap.put("1254567890",new Customer("Hari","Bangalore","1254567890"));
	cmap.put("1264567890",new Customer("karthi","Hydrabad","1264567890"));
	al.add(Mobile(107,12000,"Asus"));
	al.add(Mobile(108,10000,"Xiaomi"));
	al.add(Mobile(109,50000,"Iphone"));
	al.add(Mobile(106,17000,"Sony"));
}

public static HashMap<Integer, Mobile> addmobiledetails(Mobile md) {
	// TODO Auto-generated method stub
	int max=5000;
	int min=0;
	int range=(max-min);
	int orderid=(int) (Math.random()*range);
	
		map.put(md.getMobileorderid(),md);
		return map;
	}
private static Mobile Mobile(int i, int j, String string) {
	// TODO Auto-generated method stub
	Mobile e=new Mobile(i, j, string);
	return e;
}
public static HashMap<String, Customer> addcustomerdetails(Customer c) {
	// TODO Auto-generated method stub
	cmap.put(c.getMobileno(), c);
	return cmap;
	}
public static HashMap<Integer, Mobile> removemobile(int id){
	// TODO Auto-generated method stub
	map.remove(id);
	return map;
	}
public static HashMap<String, Customer> removecustomer(int mobileno){
	// TODO Auto-generated method stub
	cmap.remove(mobileno);
	return cmap;
	}
public static ArrayList<Mobile> sorting() {
	// TODO Auto-generated method stub
	Collections.sort(al, new Sorting()); 
	 System.out.println("\nSorted by rollno"); 
    for (int i=0; i<al.size(); i++) 
        System.out.println(al.get(i));
	return al; 
} 
public static ArrayList<Mobile> sorting1() {
	// TODO Auto-generated method stub
	Collections.sort(al, new Sorting1()); 
	 System.out.println("\nSorted by model"); 
   for (int i=0; i<al.size(); i++) 
       System.out.println(al.get(i));
	return al; 
} 
public static ArrayList<Mobile> sorting2() {
	// TODO Auto-generated method stub
	Collections.sort(al, new Sorting2()); 
	 System.out.println("\nSorted by price"); 
   for (int i=0; i<al.size(); i++) 
       System.out.println(al.get(i));
	return al; 
}
}
