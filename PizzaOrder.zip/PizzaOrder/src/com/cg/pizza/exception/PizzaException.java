package com.cg.pizza.exception;

public class PizzaException extends Exception
{

	public PizzaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
