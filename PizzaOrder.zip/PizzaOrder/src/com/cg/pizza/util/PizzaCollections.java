package com.cg.pizza.util;


import java.util.HashMap;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaOrder;
import com.cg.pizza.exception.PizzaException;

public class PizzaCollections {
	
	static HashMap<Integer,PizzaOrder> hs=new HashMap<Integer,PizzaOrder>();
	static
	{

		hs.put(1001,new PizzaOrder(1001,1234,567788));
		hs.put(1003,new PizzaOrder(1003,123765,56778894));
		hs.put(1002,new PizzaOrder(1002,123423,56778822));
	}
	static HashMap<Integer,Customer> hm=new HashMap<Integer,Customer>();
	static
	{

		hm.put(1234,new Customer(1234,"sneha","ghgg","7659077221"));
		hm.put(123765,new Customer(123765,"maira","jhgj","6768879879"));
		hm.put(123423,new Customer(123423,"hiuh","hgjhj","7687686786"));
	}
	

public static int placeOrder(Customer c,PizzaOrder pizza) {
	return pizza.getOrderId();
	
}
public static PizzaOrder getOrderDetails(int orderid) throws PizzaException {
	
	return hs.get(orderid);
}
	}


