package com.cg.pizza.dao;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaOrder;
import com.cg.pizza.exception.PizzaException;

public interface IPizzaOrderDAO {
public int placeOrder(Customer c,PizzaOrder p)throws PizzaException;
public PizzaOrder getOrderDetails(int orderid) throws PizzaException;

}
