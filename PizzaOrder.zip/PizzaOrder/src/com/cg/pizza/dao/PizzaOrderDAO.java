package com.cg.pizza.dao;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaOrder;
import com.cg.pizza.exception.PizzaException;
import com.cg.pizza.util.PizzaCollections;
public class PizzaOrderDAO implements IPizzaOrderDAO {

	@Override
	public int placeOrder(Customer c, PizzaOrder p) throws PizzaException {
		return	PizzaCollections.placeOrder(c, p);
		
       
	
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		
		return PizzaCollections.getOrderDetails(orderid);
	}

}
