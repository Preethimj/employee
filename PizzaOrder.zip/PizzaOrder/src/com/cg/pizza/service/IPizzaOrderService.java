package com.cg.pizza.service;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaOrder;
import com.cg.pizza.exception.PizzaException;

public interface IPizzaOrderService {
	public int placeOrder(Customer c,PizzaOrder p)throws PizzaException;
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
	public boolean ValidateName(String name);
	public boolean ValidateNumber(String num);
}
