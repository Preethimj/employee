package com.cg.pizza.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pizza.dao.IPizzaOrderDAO;
import com.cg.pizza.dao.PizzaOrderDAO;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaOrder;
import com.cg.pizza.exception.PizzaException;


public class PizzaOrderService implements IPizzaOrderService {
	IPizzaOrderDAO dao=new PizzaOrderDAO();
	@Override
	public int placeOrder(Customer c, PizzaOrder p) throws PizzaException {
		return dao.placeOrder(c, p);
		
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		
		return dao.getOrderDetails(orderid);
	}

	@Override
	public boolean ValidateNumber(String num) {
		Pattern pattern=Pattern.compile("[0-9]{10}");
		Matcher m=pattern.matcher(num);
		if(m.matches()) {
			return true;
		}
		
		
		return false;
	}
	@Override
	public boolean ValidateName(String name) {
		Pattern pattern=Pattern.compile("[a-z]{3,10}");
		Matcher m=pattern.matcher(name);
		if(m.matches()) {
			return true;
		}
		
		
		return false;
	}

}
