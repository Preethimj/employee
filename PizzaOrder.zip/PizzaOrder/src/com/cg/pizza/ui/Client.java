package com.cg.pizza.ui;

import java.util.Scanner;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaOrder;
import com.cg.pizza.exception.PizzaException;
import com.cg.pizza.service.IPizzaOrderService;
import com.cg.pizza.service.PizzaOrderService;

public class Client
{ 
	static Scanner sc=null;
	static IPizzaOrderService pizzaservice=null;

public static void main(String[] args) throws PizzaException
{
	sc=new Scanner(System.in);
	pizzaservice=new PizzaOrderService();
	System.out.println("*****Menu******");
	System.out.println("1.Place Order");
	System.out.println("2.getOrderDetails");
	System.out.println("3.exit");
	
     int choice=sc.nextInt();
	switch(choice)
	{
	case 1:
		placeOrder();
	    break;
	case 2:
		  getOrderDetails();
	      break;
	case 3:
		System.exit(0);
	    break;
	default :
		System.out.println("enter valid choice");
}
	
}

private static void getOrderDetails() throws PizzaException {
	System.out.println("Enter the OrderId");
	int orderid=sc.nextInt();
	PizzaOrder p=pizzaservice.getOrderDetails(orderid);
	System.out.println(p);

	
}

private static void placeOrder() {
	System.out.println("Enter the Customer's name");
	String name=sc.next();
	if (pizzaservice.ValidateName(name)) 
	{
		System.out.println("Enter the Customer's number");
		String num=sc.next();
		if (pizzaservice.ValidateNumber(num)) 
		{
		System.out.println("Enter the Customer's address");
		String address=sc.next();
		 int base=350;
		 System.out.println("Choose your pizza toppings");
		 System.out.println("1.Capsicum");
		 System.out.println("2.Mushroom");
		 System.out.println("3.Jalpeno");
		 System.out.println("4.Paneer");
		
		 int price =0;
		 int ch=0;
		 ch=sc.nextInt();
		 switch(ch) {
		 case 1: 
			  price = base+30;
			 break;
		 case 2: 
			  price = base+50;
			 break;
		 case 3: 
			  price = base+70;
			 break;
		 case 4: 
			  price = base+85;
			 break;
	    default : 
	    	 System.out.println("enter valid choice");	
		 }
				
		int custid=(int)Math.round(Math.random()*999999999);
		int orderid=(int)Math.round(Math.random()*999999999);
		Customer c=new Customer(custid,name,num,address);
		PizzaOrder p=new PizzaOrder(orderid,custid,price);
				System.out.println("Order id generated successfully");
		System.out.println(orderid);
		System.out.println(price);
	
	
			
}
		
		}
	
}	
	
}



